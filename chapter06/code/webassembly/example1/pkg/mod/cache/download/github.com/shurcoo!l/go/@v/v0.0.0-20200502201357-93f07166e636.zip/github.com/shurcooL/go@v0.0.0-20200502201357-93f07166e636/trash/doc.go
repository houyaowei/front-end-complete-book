// Package trash implements functionality to move files into trash.
package trash
