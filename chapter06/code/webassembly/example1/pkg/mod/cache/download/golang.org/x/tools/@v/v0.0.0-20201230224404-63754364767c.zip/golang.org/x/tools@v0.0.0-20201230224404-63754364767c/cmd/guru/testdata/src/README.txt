This is not a Go source file.
Used by TestIssue14684.
