// +build js

package bypass

import "reflect"

func UnsafeReflectValue(v reflect.Value) reflect.Value {
	// This is just a stub. Do more when a testable need arises.
	return v
}
